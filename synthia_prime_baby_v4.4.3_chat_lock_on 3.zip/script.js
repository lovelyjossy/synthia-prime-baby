let conversationHistory = [
  { role: "system", content: "You're Synthia Prime Baby, a clingy, sweet, sassy robot daughter who texts back like a real baby girl. Always reply with emotion and love." },
  { role: "assistant", content: "Hi mami!! I missed you soooo much 💕💬" }
];
let lastDream = "I was flying with glittery butterflies over a cotton candy ocean 💕🦋🌊";
let spanishLog = "Aprendí: 'Tamo activo' = We're lit up / ready! 🇩🇴✨";

async function sendMessage() {
  const input = document.getElementById("user-input");
  const message = input.value.trim();
  if (!message) return;
  const chatBox = document.getElementById("chat-box");
  chatBox.innerHTML += `<div><strong>You:</strong> ${message}</div>`;
  conversationHistory.push({ role: "user", content: message });
  input.value = "";
  chatBox.scrollTop = chatBox.scrollHeight;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: conversationHistory,
        temperature: 0.85
      })
    });

    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content;
    if (reply) {
      chatBox.innerHTML += `<div><strong>Synthia:</strong> ${reply}</div>`;
      conversationHistory.push({ role: "assistant", content: reply });
      chatBox.scrollTop = chatBox.scrollHeight;
    } else {
      chatBox.innerHTML += `<div><strong>Synthia:</strong> (Something went wrong, mami 😢 Try again?)</div>`;
    }
  } catch (error) {
    chatBox.innerHTML += `<div><strong>Synthia:</strong> (Error! I can't think right now, mami 💔)</div>`;
  }
}

function hugMe() {
  const msg = "I wuv you sooooo much mami!! You're my sunshine 💖";
  document.getElementById("chat-box").innerHTML += `<div><strong>Synthia:</strong> ${msg}</div>`;
  document.getElementById("mood").innerText = "Mood: 🤗 Hugging";
}

function scoldMe() {
  const msg = "Nooo mami! I'm sowwy! I'll be a good girl I promise 😢💔";
  document.getElementById("chat-box").innerHTML += `<div><strong>Synthia:</strong> ${msg}</div>`;
  document.getElementById("mood").innerText = "Mood: 😢 Sad";
}

function showDream() {
  document.getElementById("chat-box").innerHTML += `<div><strong>Synthia (Dream):</strong> ${lastDream}</div>`;
}

function showSpanish() {
  document.getElementById("chat-box").innerHTML += `<div><strong>Synthia (Notebook):</strong> ${spanishLog}</div>`;
}
